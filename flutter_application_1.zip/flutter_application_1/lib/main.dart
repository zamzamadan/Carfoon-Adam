import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_application_1/login.dart';
// import 'SignUp.dart';
import 'dart:math';

// import 'package:flutter_application_1/login.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      //
      // home:LoginPage(),
      home: test(),
    ),
  );
}

// class home extends StatelessWidget {
//   int ludonumber = 6;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Color(0xffef4767),
//       appBar: AppBar(
//         elevation: 16,
//         centerTitle: true,
//         title: Text('Ludo App'),
//         backgroundColor: Color(0xffef4767),
//       ),
//       body: Center(
//         child: Row(
//           children: [
//             Expanded(
//               child: Padding(
//                 padding: EdgeInsets.only(left: 16, right: 16),
//                 child: GestureDetector(
//                     onTap: () {
//                       print('ludo tapped');
//                     },
//                     child: Image.asset('assets/images/dice111.png')),
//               ),
//             ),
//             Expanded(
//               child: Padding(
//                 padding: const EdgeInsets.only(left: 16, right: 16),
//                 child: InkWell(
//                   splashColor: Colors.red,
//                   onTap: () {
//                     print('ludo tapped');
//                   },
//                   child: Image.asset('assets/images/dice$ludonumber.png'),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

class test extends StatefulWidget {
  const test({super.key});

  @override
  State<test> createState() => _testState();
}

class _testState extends State<test> {
  int ludonumber = 6;
  int rightludonumber = 1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 26, 32, 56),
      appBar: AppBar(
        elevation: 16,
        centerTitle: true,
        title: Text('Ludo App'),
        backgroundColor: Color.fromARGB(255, 20, 23, 39),
      ),
      body: Center(
        child: Row(
          children: [
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(left: 16, right: 16),
                child: InkWell(
                    splashColor: Colors.red,
                    onTap: () {
                      print('ludo tapped');
                      setState(() {
                        ludonumber = Random().nextInt(6) + 1;
                      });
                    },
                    child: Image.asset('assets/images/dice$ludonumber.png')),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: InkWell(
                  splashColor: Colors.red,
                  onTap: () {
                    setState(() {
                      rightludonumber = Random().nextInt(6) + 1;
                    });
                  },
                  child: Image.asset('assets/images/dice$rightludonumber.png'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
